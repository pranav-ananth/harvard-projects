# WORDLE
Wordle Game Adapted From Stanford's Nifty Assignments: http://nifty.stanford.edu/2022/eroberts-spelling-bee-wordle/

0. Download all of the source code and add it to your project.

1. Follow the directions in the handout, WordleAssignment.pdf.

2. Upload Wordle.java to codePost for testing.

3. In Canvas, attach some screenshots of your output.


