/**
 * File: Wordle.java
 * @author Pranav Ananth
 * @version 11/8/2024
 * This module is the starter file for the Wordle assignment.
 * This program creates a Wordle game.
 */

import java.util.Locale;

public class Wordle {
    
    /* Private instance variables */
    // TODO: Add any extra instance variables here, if any
    private WordleGWindow gw;
    private String word;
    
    
    public void run() {
        // DEBUG: useful for testing
        word = chooseWord(); // choose random word
        gw = new WordleGWindow();
        gw.addEnterListener((s) -> enterAction(s));
        System.out.println("Guess word is : " + word);
    }
    
    /**
     * returns a random word from WordleDictionary.
     */
    public String chooseWord(){
         // TODO
        int i = getRandomNumber(0, WordleDictionary.FIVE_LETTER_WORDS.length - 1);
         return ((String)WordleDictionary.FIVE_LETTER_WORDS[i]).toUpperCase();
    }

    /**
     *
     * @param min
     * @param max
     * @return A random number in the range between min and max
     */
    public int getRandomNumber(int min, int max) {
        return (int) ((Math.random() * (max - min)) + min);
    }

    /*
     * Called when the user hits the RETURN key or clicks the ENTER button,
     * passing in the string of characters on the current row.
     */
    public void enterAction(String s) {
        boolean found = false;
        for (int i = 0; i < WordleDictionary.FIVE_LETTER_WORDS.length; i++) {
            if (s.compareToIgnoreCase( (String)WordleDictionary.FIVE_LETTER_WORDS[i]) == 0) {
                found = true;
                break;
            }
        }
        if (found) {
            String output = getHint(s, word);
            System.out.println("The output from gethint is " + output);
            for (int i = 0; i < s.length(); i++) {
                char ch = output.charAt(i);
                // Color squares/keys
                if (Character.isUpperCase(ch)) {
                    gw.setSquareColor(gw.getCurrentRow(), i, WordleGWindow.CORRECT_COLOR);
                    gw.setKeyColor(String.valueOf(ch),WordleGWindow.CORRECT_COLOR);
                }
                else if (ch == '*') {
                    gw.setSquareColor(gw.getCurrentRow(), i, WordleGWindow.MISSING_COLOR);
                    gw.setKeyColor(s.substring(i, i+1),WordleGWindow.MISSING_COLOR);
                }
                else {
                    if (gw.getKeyColor(String.valueOf(ch).toUpperCase()) != WordleGWindow.CORRECT_COLOR) {
                        gw.setKeyColor(String.valueOf(ch).toUpperCase(), WordleGWindow.PRESENT_COLOR);
                    }
                    gw.setSquareColor(gw.getCurrentRow(), i, WordleGWindow.PRESENT_COLOR);
                }
            }
            // Check if solution is right
            if(output.equals(word)) {
                gw.showMessage("Nice work!");
            }
            else {
                // Check if there are still guesses left
                if(gw.getCurrentRow() < gw.N_ROWS - 1) {
                    gw.setCurrentRow(gw.getCurrentRow()+1);
                }
                else {
                    gw.showMessage("Too bad...the word was " + word.toLowerCase());
                }
            }
        }
        else {
            gw.showMessage("Not in word list");
        }
    }

    /**
     * @param guess the user's guess
     * @param word the secret word to be guessed
     * @return a String version of the hint where a capital letter
     * represents a correct guess at the correct location, a lower
     * case letter represents a correct guess at the wrong location,
     * and a '*' represents an incorrect letter (neither in the
     * correct place nor a correct letter anywhere in the word)
     *
     * You will use this helper method when coloring the squares.
     * It's also the crucial method that is tested in codePost.
     *
     * Examples:
     * word        = "CLASS"
     * guess       = "SASSY"
     * returns:      "sa*S*"
     *
     * word        = "FLUFF"
     * guess       = "OFFER"
     * returns:      "*ff**"
     *
     * word        = "STACK"
     * guess       = "TASTE"
     * returns:      "tas**"
     *
     * word        = "MYTHS"
     * guess       = "HITCH"
     * returns:      "h*T**"
     *
     */

    public static String getHint(String guess, String word) {
        StringBuilder hint = new StringBuilder("*****");
        // Boolean array to track matched letters in the word
        boolean[] matched = new boolean[word.length()];

        for (int i = 0; i < guess.length(); i++) {
            if (guess.charAt(i) == word.charAt(i)) {
                hint.setCharAt(i, Character.toUpperCase(guess.charAt(i)));
                matched[i] = true; // Mark this position as matched
            }
        }

        for (int i = 0; i < guess.length(); i++) {
            if (hint.charAt(i) != '*')
                continue; // Skip already matched characters
            char guessChar = guess.charAt(i);

            // Check if the guessed character exists elsewhere in the word
            for (int j = 0; j < word.length(); j++) {
                if (guessChar == word.charAt(j) && !matched[j]) {
                    hint.setCharAt(i, Character.toLowerCase(guessChar));
                    matched[j] = true; // Mark this position as matched
                    break; // Stop checking after finding the first match
                }
            }
        }

        return hint.toString();
    }


/* Startup code */

    public static void main(String[] args) {
        new Wordle().run();
    }


}